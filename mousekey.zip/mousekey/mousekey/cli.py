
import argparse
from .mousekey import mousekey


def main():
    print("Starting Mousekey...")
    mousekey()
if __name__ == "__main__":
    main()