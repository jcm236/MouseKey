from pynput import keyboard
import pyautogui
import time
def mousekey():
    def on_press(key):
        
        if key == keyboard.Key.right:
            pyautogui.move(5, 0)
        
        if key == keyboard.Key.left:
            pyautogui.move(-5, 0)
        
        if key == keyboard.Key.up:
            pyautogui.move(0, -5)
        
        if key == keyboard.Key.down:
            pyautogui.move(0, 5)
        
    

    def on_release(key):
        if key == keyboard.Key.esc:
            return False


    with keyboard.Listener(
            on_press=on_press,
            on_release=on_release) as listener:
        listener.join()  
        time.sleep(1)  
              

