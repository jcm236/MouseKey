import setuptools

setuptools.setup(
    name="mousekey",
    version="1.0",
    author="John Christi",
    author_email="",
    description=("Mousekey is an application which allows controlling of the mouse pointer using the arrow keys"),
    long_description_content_type="text/markdown",
    url="https://github.com/john-christi/PictoPaper",
    project_urls={
        "Bug Tracker": "https://github.com/john-christi/Mousekey/issues",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    install_requires=["pynput", "pyautogui"],
    packages=setuptools.find_packages(),
    python_requires=">=3.6",
    entry_points={
        "console_scripts": [
            "mousekey = mousekey.cli:main",
        ]
    }
)